<?php
/**
 * Plugin Name: Disciple Tools - Personal Goal Settings Plugin
 * Plugin URI: https://github.com/DiscipleTools/disciple-tools-personal-goal-settings-plugin
 * Description: Disciple Tools - Personal Goal Settings Plugin is intended to help developers and integrator jumpstart their extension
 * of the Disciple Tools system.
 * Version:  0.1.0
 * Author URI: https://github.com/DiscipleTools
 * GitHub Plugin URI: https://github.com/DiscipleTools/disciple-tools-starter-plugin
 * Requires at least: 4.7.0
 * (Requires 4.7+ because of the integration of the REST API at 4.7 and the security requirements of this milestone version.)
 * Tested up to: 5.4
 *
 * @package Disciple_Tools
 * @link    https://github.com/DiscipleTools
 * @license GPL-2.0 or later
 *          https://www.gnu.org/licenses/gpl-2.0.html
 */

/*******************************************************************
 * Using the Personal Goal Settings Plugin
 * The Disciple Tools Personal Goal Settings Plugin is intended to accelerate integrations and extensions to the Disciple Tools system.
 * This basic plugin starter has some of the basic elements to quickly launch and extension project in the pattern of
 * the Disciple Tools system.
 */

/**
 * Refactoring (renaming) this plugin as your own:
 * 1. @todo Refactor all occurrences of the name DT_Starter, dt_starter, dt-starter, starter-plugin, starter_post_type, and Personal Goal Settings Plugin
 * 2. @todo Rename the `disciple-tools-starter-plugin.php and menu-and-tabs.php files.
 * 3. @todo Update the README.md and LICENSE
 * 4. @todo Update the default.pot file if you intend to make your plugin multilingual. Use a tool like POEdit
 * 5. @todo Change the translation domain to in the phpcs.xml your plugin's domain: @todo
 * 6. @todo Replace the 'sample' namespace in this and the rest-api.php files
 */

/**
 * The Personal Goal Settings Plugin is equipped with:
 * 1. Wordpress style requirements
 * 2. Travis Continuous Integration
 * 3. Disciple Tools Theme presence check
 * 4. Remote upgrade system for ongoing updates outside the Wordpress Directory
 * 5. Multilingual ready
 * 6. PHP Code Sniffer support (composer) @use /vendor/bin/phpcs and /vendor/bin/phpcbf
 * 7. Starter Admin menu and options page with tabs.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
$dt_starter_required_dt_theme_version = '0.28.0';

/**
 * Gets the instance of the `DT_Personal_Goal_Settings_Plugin` class.
 *
 * @since  0.1
 * @access public
 * @return object|bool
 */
function dt_personal_goal_settings_plugin() {
    global $dt_starter_required_dt_theme_version;
    $wp_theme = wp_get_theme();
    $version = $wp_theme->version;

    /*
     * Check if the Disciple.Tools theme is loaded and is the latest required version
     */
    $is_theme_dt = strpos( $wp_theme->get_template(), "disciple-tools-theme" ) !== false || $wp_theme->name === "Disciple Tools";
    if ( $is_theme_dt && version_compare( $version, $dt_starter_required_dt_theme_version, "<" ) ) {
        add_action( 'admin_notices', 'dt_starter_plugin_hook_admin_notice' );
        add_action( 'wp_ajax_dismissed_notice_handler', 'dt_hook_ajax_notice_handler' );
        return false;
    }
    if ( !$is_theme_dt ){
        return false;
    }
    /**
     * Load useful function from the theme
     */
    if ( !defined( 'DT_FUNCTIONS_READY' ) ){
        require_once get_template_directory() . '/dt-core/global-functions.php';
    }
    /*
     * Don't load the plugin on every rest request. Only those with the 'sample' namespace
     */
    $is_rest = dt_is_rest();
    //@todo change 'sample' if you want the plugin to be set up when using rest api calls other than ones with the 'sample' namespace
    if ( ! $is_rest ){
        return DT_Personal_Goal_Settings_Plugin::get_instance();
    }
    // @todo remove this "else if", if not using rest-api.php
    else if ( strpos( dt_get_url_path(), 'dt_personal_goal_settings_plugin' ) !== false ) {
        return DT_Personal_Goal_Settings_Plugin::get_instance();
    }
    // @todo remove if not using a post type
    else if ( strpos( dt_get_url_path(), 'starter_post_type' ) !== false) {
        return DT_Personal_Goal_Settings_Plugin::get_instance();
    }
}
add_action( 'after_setup_theme', 'dt_personal_goal_settings_plugin' );

add_filter( 'desktop_navbar_menu_options', 'add_navigation_links', 25 );
add_filter( 'off_canvas_menu_options', 'add_navigation_links', 25);
add_filter( 'dt_templates_for_urls', 'add_template_for_url', 25 );

function add_navigation_links( $tabs ) {
    //check user permissions
    // if ( current_user_can( 'access_' . $this->post_type ) ) {
    
        $tabs[] = [
            "link" => site_url( "/personal-goals/" ), // the link where the user will be directed when they click
            "label" => __( "Personal Goals", "disciple_tools" )  // the label the user will see
        ];
        
    // }
    return $tabs;
}

function add_template_for_url( $template_for_url ){
    $template_for_url['personal-goals'] = 'personal-goals.php';
    $template_for_url['personal-goals/new'] = 'new-personal-goals.php';
    $template_for_url['personal-goals/edit'] = 'edit-personal-goals.php';
    return $template_for_url;
}

/**
 * Singleton class for setting up the plugin.
 *
 * @since  0.1
 * @access public
 */
class DT_Personal_Goal_Settings_Plugin {

    /**
     * Declares public variables
     *
     * @since  0.1
     * @access public
     * @return object
     */
    public $token;
    public $version;
    public $dir_path = '';
    public $dir_uri = '';
    public $img_uri = '';
    public $includes_path;

    /**
     * Returns the instance.
     *
     * @since  0.1
     * @access public
     * @return object
     */
    public static function get_instance() {

        static $instance = null;

        if ( is_null( $instance ) ) {
            $instance = new dt_personal_goal_settings_plugin();
            $instance->setup();
            $instance->includes();
            $instance->setup_actions();
        }
        return $instance;
    }

    /**
     * Constructor method.
     *
     * @since  0.1
     * @access private
     * @return void
     */
    private function __construct() {
    }

    /**
     * Loads files needed by the plugin.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    private function includes() {
        if ( is_admin() ) {
            require_once( 'includes/admin/admin-menu-and-tabs.php' );
        }
    }

    /**
     * Sets up globals.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    private function setup() {

        // Main plugin directory path and URI.
        $this->dir_path     = trailingslashit( plugin_dir_path( __FILE__ ) );
        $this->dir_uri      = trailingslashit( plugin_dir_url( __FILE__ ) );

        // Plugin directory paths.
        $this->includes_path      = trailingslashit( $this->dir_path . 'includes' );

        // Plugin directory URIs.
        $this->img_uri      = trailingslashit( $this->dir_uri . 'img' );

        // Admin and settings variables
        $this->token             = 'dt_personal_goal_settings_plugin';
        $this->version             = '0.1';



        // sample rest api class
        require_once( 'includes/rest-api.php' );

        // sample post type class
        // require_once( 'includes/post-type.php' );

        // custom site to site links
        require_once( 'includes/custom-site-to-site-links.php' );

    }

    /**
     * Sets up main plugin actions and filters.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    private function setup_actions() {

        if ( is_admin() ){
            // Check for plugin updates
            if ( ! class_exists( 'Puc_v4_Factory' ) ) {
                require( get_template_directory() . '/dt-core/libraries/plugin-update-checker/plugin-update-checker.php' );
            }
            /**
             * Below is the publicly hosted .json file that carries the version information. This file can be hosted
             * anywhere as long as it is publicly accessible. You can download the version file listed below and use it as
             * a template.
             * Also, see the instructions for version updating to understand the steps involved.
             * @see https://github.com/DiscipleTools/disciple-tools-version-control/wiki/How-to-Update-the-Starter-Plugin
             * @todo enable this section with your own hosted file
             * @todo An example of this file can be found in /includes/admin/disciple-tools-starter-plugin-version-control.json
             * @todo It is recommended to host this version control file outside the project itself. Github is a good option for delivering static json.
             */

            /***** @todo remove from here

            $hosted_json = "https://raw.githubusercontent.com/DiscipleTools/disciple-tools-version-control/master/disciple-tools-starter-plugin-version-control.json"; // @todo change this url
            Puc_v4_Factory::buildUpdateChecker(
                $hosted_json,
                __FILE__,
                'disciple-tools-starter-plugin'
            );

            ********* @todo to here */

        }

        // Internationalize the text strings used.
        add_action( 'init', array( $this, 'i18n' ), 2 );

        if ( is_admin() ) {
            // adds links to the plugin description area in the plugin admin list.
            add_filter( 'plugin_row_meta', [ $this, 'plugin_description_links' ], 10, 4 );
        }
    }

    /**
     * Filters the array of row meta for each/specific plugin in the Plugins list table.
     * Appends additional links below each/specific plugin on the plugins page.
     *
     * @access  public
     * @param   array       $links_array            An array of the plugin's metadata
     * @param   string      $plugin_file_name       Path to the plugin file
     * @param   array       $plugin_data            An array of plugin data
     * @param   string      $status                 Status of the plugin
     * @return  array       $links_array
     */
    public function plugin_description_links( $links_array, $plugin_file_name, $plugin_data, $status ) {
        if ( strpos( $plugin_file_name, basename( __FILE__ ) ) ) {
            // You can still use `array_unshift()` to add links at the beginning.

            $links_array[] = '<a href="https://disciple.tools">Disciple.Tools Community</a>'; // @todo replace with your links.

            // add other links here
        }

        return $links_array;
    }

    /**
     * Method that runs only when the plugin is activated.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    public static function activation() {

        // Confirm 'Administrator' has 'manage_dt' privilege. This is key in 'remote' configuration when
        // Disciple Tools theme is not installed, otherwise this will already have been installed by the Disciple Tools Theme
        $role = get_role( 'administrator' );
        if ( !empty( $role ) ) {
            $role->add_cap( 'manage_dt' ); // gives access to dt plugin options
        }

        $personalGoalTemplates = [];

        add_option('vc_personal_goal_templates', json_encode($personalGoalTemplates));
        
        $sourceFile = __DIR__.DIRECTORY_SEPARATOR."personal-goals.php";
        $destinationFile = str_replace("/wp-content", "/wp-content/themes/disciple-tools-theme-master", WP_CONTENT_DIR).DIRECTORY_SEPARATOR."personal-goals.php";
        copy($sourceFile, $destinationFile);
        
        $sourceFile = __DIR__.DIRECTORY_SEPARATOR."new-personal-goals.php";
        $destinationFile = str_replace("/wp-content", "/wp-content/themes/disciple-tools-theme-master", WP_CONTENT_DIR).DIRECTORY_SEPARATOR."new-personal-goals.php";
        copy($sourceFile, $destinationFile);
        
        $sourceFile = __DIR__.DIRECTORY_SEPARATOR."edit-personal-goals.php";
        $destinationFile = str_replace("/wp-content", "/wp-content/themes/disciple-tools-theme-master", WP_CONTENT_DIR).DIRECTORY_SEPARATOR."edit-personal-goals.php";
        copy($sourceFile, $destinationFile);
        
        add_option('vc_sourceFile', $sourceFile);
        add_option('vc_destinationFile', $destinationFile);
    }

    /**
     * Method that runs only when the plugin is deactivated.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    public static function deactivation() {
        
        delete_option( 'dismissed-dt-starter' );
        delete_option('vc_personal_goal_templates');
        delete_option('vc_sourceFile');
        delete_option('vc_destinationFile');

        $destinationFile = str_replace("/wp-content", "/wp-content/themes/disciple-tools-theme-master", WP_CONTENT_DIR).DIRECTORY_SEPARATOR."personal-goals.php";

        if (file_exists($destinationFile)) {
            unlink($destinationFile);
        }

        $destinationFile2 = str_replace("/wp-content", "/wp-content/themes/disciple-tools-theme-master", WP_CONTENT_DIR).DIRECTORY_SEPARATOR."new-personal-goals.php";

        if (file_exists($destinationFile2)) {
            unlink($destinationFile2);
        }

        $destinationFile3 = str_replace("/wp-content", "/wp-content/themes/disciple-tools-theme-master", WP_CONTENT_DIR).DIRECTORY_SEPARATOR."edit-personal-goals.php";

        if (file_exists($destinationFile3)) {
            unlink($destinationFile3);
        }
    }

    /**
     * Loads the translation files.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    public function i18n() {
        load_plugin_textdomain( 'dt_personal_goal_settings_plugin', false, trailingslashit( dirname( plugin_basename( __FILE__ ) ) ). 'languages' );
    }

    /**
     * Magic method to output a string if trying to use the object as a string.
     *
     * @since  0.1
     * @access public
     * @return string
     */
    public function __toString() {
        return 'dt_personal_goal_settings_plugin';
    }

    /**
     * Magic method to keep the object from being cloned.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    public function __clone() {
        _doing_it_wrong( __FUNCTION__, 'Whoah, partner!', '0.1' );
    }

    /**
     * Magic method to keep the object from being unserialized.
     *
     * @since  0.1
     * @access public
     * @return void
     */
    public function __wakeup() {
        _doing_it_wrong( __FUNCTION__, 'Whoah, partner!', '0.1' );
    }

    /**
     * Magic method to prevent a fatal error when calling a method that doesn't exist.
     *
     * @param string $method
     * @param array $args
     * @return null
     * @since  0.1
     * @access public
     */
    public function __call( $method = '', $args = array() ) {
        _doing_it_wrong( "dt_personal_goal_settings_plugin::" . esc_html( $method ), 'Method does not exist.', '0.1' );
        unset( $method, $args );
        return null;
    }
}
// end main plugin class

// Register activation hook.
register_activation_hook( __FILE__, [ 'DT_Personal_Goal_Settings_Plugin', 'activation' ] );
register_deactivation_hook( __FILE__, [ 'DT_Personal_Goal_Settings_Plugin', 'deactivation' ] );

function dt_starter_plugin_hook_admin_notice() {
    global $dt_starter_required_dt_theme_version;
    $wp_theme = wp_get_theme();
    $current_version = $wp_theme->version;
    $message = __( "'Disciple Tools - Personal Goal Settings Plugin' plugin requires 'Disciple Tools' theme to work. Please activate 'Disciple Tools' theme or make sure it is latest version.", "dt_personal_goal_settings_plugin" );
    if ( $wp_theme->get_template() === "disciple-tools-theme" ){
        $message .= sprintf( esc_html__( 'Current Disciple Tools version: %1$s, required version: %2$s', 'dt_personal_goal_settings_plugin' ), esc_html( $current_version ), esc_html( $dt_starter_required_dt_theme_version ) );
    }
    // Check if it's been dismissed...
    if ( ! get_option( 'dismissed-dt-starter', false ) ) { ?>
        <div class="notice notice-error notice-dt-starter is-dismissible" data-notice="dt-starter">
            <p><?php echo esc_html( $message );?></p>
        </div>
        <script>
            jQuery(function($) {
                $( document ).on( 'click', '.notice-dt-starter .notice-dismiss', function () {
                    $.ajax( ajaxurl, {
                        type: 'POST',
                        data: {
                            action: 'dismissed_notice_handler',
                            type: 'dt-starter',
                            security: '<?php echo esc_html( wp_create_nonce( 'wp_rest_dismiss' ) ) ?>'
                        }
                    })
                });
            });
        </script>
    <?php }
}


/**
 * AJAX handler to store the state of dismissible notices.
 */
if ( !function_exists( "dt_hook_ajax_notice_handler" )){
    function dt_hook_ajax_notice_handler(){
        check_ajax_referer( 'wp_rest_dismiss', 'security' );
        if ( isset( $_POST["type"] ) ){
            $type = sanitize_text_field( wp_unslash( $_POST["type"] ) );
            update_option( 'dismissed-' . $type, true );
        }
    }
}
