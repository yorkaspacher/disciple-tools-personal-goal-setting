<?php
/**
 * DT_Personal_Goal_Settings_Plugin_Menu class for the admin page
 *
 * @class       DT_Personal_Goal_Settings_Plugin_Menu
 * @version     0.1.0
 * @since       0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; // Exit if accessed directly
}

/**
 * Initialize menu class
 */
DT_Personal_Goal_Settings_Plugin_Menu::instance();

/**
 * Class DT_Personal_Goal_Settings_Plugin_Menu
 */
class DT_Personal_Goal_Settings_Plugin_Menu {

    public $token = 'dt_starter_plugin';

    private static $_instance = null;

    /**
     * DT_Personal_Goal_Settings_Plugin_Menu Instance
     *
     * Ensures only one instance of DT_Personal_Goal_Settings_Plugin_Menu is loaded or can be loaded.
     *
     * @since 0.1.0
     * @static
     * @return DT_Personal_Goal_Settings_Plugin_Menu instance
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    } // End instance()


    /**
     * Constructor function.
     * @access  public
     * @since   0.1.0
     */
    public function __construct() {

        add_action( "admin_menu", array( $this, "register_menu" ) );

    } // End __construct()


    /**
     * Loads the subnav page
     * @since 0.1
     */
    public function register_menu() {
        add_menu_page( __( 'Extensions (DT)', 'disciple_tools' ), __( 'Extensions (DT)', 'disciple_tools' ), 'manage_dt', 'dt_extensions', [ $this, 'extensions_menu' ], 'dashicons-admin-generic', 59 );
        add_submenu_page( 'dt_extensions', __( 'Personal Goal Settings Plugin', 'dt_starter_plugin' ), __( 'Personal Goal Settings Plugin', 'dt_starter_plugin' ), 'manage_dt', $this->token, [ $this, 'content' ] );
    }

    /**
     * Menu stub. Replaced when Disciple Tools Theme fully loads.
     */
    public function extensions_menu() {}

    /**
     * Builds page contents
     * @since 0.1
     */
    public function content() {

        if ( !current_user_can( 'manage_dt' ) ) { // manage dt is a permission that is specific to Disciple Tools and allows admins, strategists and dispatchers into the wp-admin
            wp_die( esc_attr__( 'You do not have sufficient permissions to access this page.' ) );
        }

        if ( isset( $_GET["tab"] ) ) {
            $tab = sanitize_key( wp_unslash( $_GET["tab"] ) );
        } else {
            $tab = 'personal-goal';
        }

        if (isset($_POST['updateGoal'])) {

            $updatedGoalTemplates = sanitize_text_field($_POST['updatedGoalTemplates']);

            update_option('vc_personal_goal_templates', stripslashes($updatedGoalTemplates));
        }

        if (isset($_POST['submitGoal'])) {

            $personalGoalTemplates = json_decode(get_option('vc_personal_goal_templates'), true);

            $fecha = new DateTime();

            $goalObject = [
                "id" => sanitize_text_field($_POST['goalId']) != "" && sanitize_text_field($_POST['goalId']) != null ? sanitize_text_field($_POST['goalId']) : $fecha->getTimestamp(),
                "goalTemplate" => sanitize_text_field($_POST['goalTemplate']),
                "kindOfGoal" => sanitize_text_field($_POST['kindOfGoal']),
                "goalDescription" => sanitize_text_field($_POST['goalDescription']),
                "goalName" => sanitize_text_field($_POST['goalName']),
                "goalDeadLine" => sanitize_text_field($_POST['goalDeadLine']),
                "goalRemindmeTime" => sanitize_text_field($_POST['goalRemindmeTime']),
                "goalOften" => sanitize_text_field($_POST['goalOften']),
                "goalRemindmeDay" => sanitize_text_field($_POST['goalRemindmeDay']),
                "goalTime" => sanitize_text_field($_POST['goalTime'])
            ];

            
            foreach ($personalGoalTemplates as $key => $value) {
                if($value["id"] == $goalObject["id"]) {
                    array_splice($personalGoalTemplates,$key,1);
                }
            }
            
            array_push($personalGoalTemplates, $goalObject);
            update_option('vc_personal_goal_templates', json_encode($personalGoalTemplates));
        }

        $personalGoalTemplates = get_option('vc_personal_goal_templates') ? json_decode(get_option('vc_personal_goal_templates')) : [];

        $link = 'admin.php?page='.$this->token.'&tab=';

        ?>
        
        <div class="wrap">
            <h2><?php esc_attr_e( 'Personal Goal Settings Plugin', 'dt_starter_plugin' ) ?></h2>
            <h2 class="nav-tab-wrapper">
                <a href="<?php echo esc_attr( $link ) . 'personal-goal' ?>" class="nav-tab nav-tab-active"><?php esc_attr_e( 'Personal Goal', 'dt_starter_plugin' ) ?></a>
            </h2>

            <?php
            switch ($tab) {
                case 'personal-goal':
                    ?>
        
                        <div class="wpbody-content">
                            <div class="wrap">
                            
                                <h1 class="wp-heading-inline">Personal Goal Templates</h1> 
                                <button class="page-title-action" id="buttonShowForm" onclick="showForm()">Add option</button>
                                <button class="page-title-action" id="buttonHideForm" style="display:none" onclick="hideForm()">Close</button>
        
                                <div id="formToAddOption" style="display: none;">
        
                                    <br>
                                    <br>
        
                                    <form action="" method="post" class="form-basic">
                                        <input type="hidden" name="updatedGoalTemplates" id="updatedGoalTemplates" >
                                        <button type="submit" name="updateGoal" id="updateGoal" style="display: none;" >submit</button>
                                    </form>
        
                                    <form action="" method="post" enctype="multipart/form-data" class="form-basic">

                                        <input type="hidden" name="goalId" id="goalId" >
        
                                        <table class="wp-list-table widefat striped users" style="padding: 10px 0;">
                                            <tbody>
                                                <tr>
                                                    <td style="vertical-align: inherit;">
                                                        <label style="display: block;">Goal Template (*)</label>
                                                        <select name="goalTemplate" id="goalTemplate">
                                                            <option value="" disabled selected>Select Option</option>
                                                            <option value="my_own">Create my own</option>
                                                        </select>
                                                    </td>
                                                    <td style="vertical-align: inherit;">
                                                        <label style="display: block;">Kind of Goal (*)</label>
                                                        <input type="radio" id="onetime" name="kindOfGoal" value="onetime">
                                                        <label for="onetime">One-Time</label><br>
                                                        <input type="radio" id="ongoing" name="kindOfGoal" value="ongoing">
                                                        <label for="ongoing">Ongoing</label>
                                                    </td>
                                                    <td style="vertical-align: inherit;">
                                                        <label style="display: block;">Description (*)</label>
                                                        <textarea name="goalDescription" id="goalDescription" cols="30" rows="4"></textarea>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="vertical-align: inherit;">
                                                        <label style="display: block;">Name (*)</label>
                                                        <input type="text" name="goalName" id="goalName">
                                                    </td>
                                                    <td style="vertical-align: inherit; display: none" id="colGoalDeadLine">
                                                        <label style="display: block;">Dead Line (*)</label>
                                                        <input type="date" name="goalDeadLine" id="goalDeadLine">
                                                    </td>
                                                    <td style="vertical-align: inherit; display: none" id="colGoalRemindmeTime">
                                                        <label style="display: block;">Remind me (*)</label>
                                                        <select name="goalRemindmeTime" id="goalRemindmeTime">
                                                            <option value="" disabled selected>Select Option</option>
                                                            <option value="1_day_before">1 day before</option>
                                                            <option value="2_day_before">2 day before</option>
                                                            <option value="3_day_before">3 day before</option>
                                                            <option value="4_day_before">4 day before</option>
                                                            <option value="5_day_before">5 day before</option>
                                                            <option value="6_day_before">6 day before</option>
                                                            <option value="1_week_before">1 week before</option>
                                                            <option value="2_week_before">2 week before</option>
                                                            <option value="3_week_before">3 week before</option>
                                                            <option value="4_week_before">4 week before</option>
                                                            <option value="5_week_before">5 week before</option>
                                                            <option value="6_week_before">6 week before</option>
                                                        </select>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="vertical-align: inherit; display: none" id="colGoalOften">
                                                        <label style="display: block;">How Often (*)</label>
                                                        <input type="radio" id="dayli" name="goalOften" value="dayli">
                                                        <label for="dayli">Dayli</label><br>
                                                        <input type="radio" id="weekly" name="goalOften" value="weekly">
                                                        <label for="weekly">Weekly</label><br>
                                                        <input type="radio" id="biWeekly" name="goalOften" value="biWeekly">
                                                        <label for="biWeekly">Bi-Weekly</label><br>
                                                        <input type="radio" id="monthy" name="goalOften" value="monthy">
                                                        <label for="monthy">Monthy</label><br>
                                                        <input type="radio" id="quarterly" name="goalOften" value="quarterly">
                                                        <label for="quarterly">Quarterly</label><br>
                                                    </td>
                                                    <td style="vertical-align: inherit; display: none" id="colGoalRemindmeDay">
                                                        <label style="display: block;">Remind me (*)</label>
                                                        <select name="goalRemindmeDay" id="goalRemindmeDay">
                                                            <option value="" disabled selected>Select Option</option>
                                                            <option value="sunday">Sunday</option>
                                                            <option value="monday">Monday</option>
                                                            <option value="tuesday">Tuesday</option>
                                                            <option value="wednesday">Wednesday</option>
                                                            <option value="thursday">Thursday</option>
                                                            <option value="friday">Friday</option>
                                                            <option value="saturday">Saturday</option>
                                                        </select>
                                                    </td>
                                                    <td style="vertical-align: inherit; display: none" id="colGoalTime">
                                                        <label style="display: block;">Whats Time (*)</label>
                                                        <input type="time" name="goalTime" id="goalTime">
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
        
                                        <p class="submit" style="text-align: center">
                                            <button type="submit" name="submitGoal" id="submitGoal" class="button button-primary">Submit Form</button>
                                        </p>
        
                                    </form>
                                
                                </div>
        
                                <br>
                                <br>
        
                                <h1 style="text-align: center;">Icon List</h1>
                                <br>
                                <table class="wp-list-table widefat striped users">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Kind Of Goal</th>
                                            <th>Description</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php foreach ($personalGoalTemplates  as $option) : ?>
                                        <tr>
                                            <td>
                                            <?php echo $option->goalName ?> <br/>
                                            <label>
                                                <a onclick="showForm('<?php echo $option->id ?>')">Edit</a>
                                                <a onclick="deleteGoalTemplate('<?php echo $option->id ?>')">Delete</a>
                                            </label>
                                            </td>
                                            <td><?php echo $option->kindOfGoal ?></td>
                                            <td><?php echo $option->goalDescription ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            
                            </div>
                        </div>
        
                        <script type="application/javascript">
        
                            var personalGoalTemplates = <?php echo json_encode($personalGoalTemplates); ?>;
                            var radios = document.querySelectorAll('input[type=radio][name="kindOfGoal"]');
                            
                            var goalTemplateSelector = document.getElementById('goalTemplate')

                            personalGoalTemplates.forEach(element => {
                                var option = document.createElement('option');
                                option.value = element.id;
                                option.innerHTML = element.goalName;
                                goalTemplateSelector.appendChild(option);
                            });

                            radios.forEach(radio => radio.addEventListener('change', () => {
                                console.log(radio.value)
                                if (radio.value == 'onetime') {
                                    document.getElementById('colGoalDeadLine').style.display = 'table-cell'
                                    document.getElementById('colGoalRemindmeTime').style.display = 'table-cell'
                                    document.getElementById('colGoalOften').style.display = 'none'
                                    document.getElementById('colGoalRemindmeDay').style.display = 'none'
                                    document.getElementById('colGoalTime').style.display = 'none'
                                }
                                else if (radio.value == 'ongoing') {
                                    document.getElementById('colGoalOften').style.display = 'table-cell'
                                    document.getElementById('colGoalRemindmeDay').style.display = 'table-cell'
                                    document.getElementById('colGoalTime').style.display = 'table-cell'
                                    document.getElementById('colGoalDeadLine').style.display = 'none'
                                    document.getElementById('colGoalRemindmeTime').style.display = 'none'
                                }
                            }));
                            
                            goalTemplateSelector.addEventListener("change", function() {

                                if (goalTemplateSelector.value != "" && goalTemplateSelector.value != "my_own") {

                                    var option = null
                                    
                                    personalGoalTemplates.forEach(element => {
                                        if(element.id == goalTemplateSelector.value){
                                            option = element
                                        }
                                    });

                                    document.getElementById("goalId").value = ""
                                    document.getElementById("goalName").value = option.goalName
                                    document.getElementById("goalDescription").value = option.goalDescription
                                    document.getElementById(option.kindOfGoal).checked = true

                                    if(option.goalOften != "" && option.goalOften != null){
                                        document.getElementById(option.goalOften).checked = true
                                    }
                                    document.getElementById("goalDeadLine").value = option.goalDeadLine
                                    document.getElementById("goalRemindmeTime").value = option.goalRemindmeTime
                                    document.getElementById("goalRemindmeDay").value = option.goalRemindmeDay
                                    document.getElementById("goalTime").value = option.goalTime

                                    var radios = document.querySelectorAll('input[type=radio][name="kindOfGoal"]');
                                    radios.forEach(radio => {
                                        if (radio.value == 'onetime' && radio.checked) {
                                            document.getElementById('colGoalDeadLine').style.display = 'table-cell'
                                            document.getElementById('colGoalRemindmeTime').style.display = 'table-cell'
                                            document.getElementById('colGoalOften').style.display = 'none'
                                            document.getElementById('colGoalRemindmeDay').style.display = 'none'
                                            document.getElementById('colGoalTime').style.display = 'none'
                                        }
                                        else if (radio.value == 'ongoing' && radio.checked) {
                                            document.getElementById('colGoalOften').style.display = 'table-cell'
                                            document.getElementById('colGoalRemindmeDay').style.display = 'table-cell'
                                            document.getElementById('colGoalTime').style.display = 'table-cell'
                                            document.getElementById('colGoalDeadLine').style.display = 'none'
                                            document.getElementById('colGoalRemindmeTime').style.display = 'none'
                                        }
                                    });
                                    document.getElementById('formToAddOption').style.display = 'block'
                                    document.getElementById('buttonShowForm').style.display = 'none'
                                    document.getElementById('buttonHideForm').style.display = 'inline-block'
                                } else {
                                    document.getElementById("goalId").value = ""
                                    Array.from( document.querySelectorAll('input[type=radio][name="kindOfGoal"]'), input => input.checked = false );
                                    Array.from( document.querySelectorAll('input[type=radio][name="goalOften"]'), input => input.checked = false );
                                    document.getElementById("goalName").value = ""
                                    document.getElementById("goalDescription").value = ""
                                    document.getElementById("goalDeadLine").value = ""
                                    document.getElementById("goalRemindmeTime").value = ""
                                    document.getElementById("goalRemindmeDay").value = ""
                                    document.getElementById("goalTime").value = ""

                                    document.getElementById('colGoalDeadLine').style.display = 'none'
                                    document.getElementById('colGoalRemindmeTime').style.display = 'none'
                                    document.getElementById('colGoalOften').style.display = 'none'
                                    document.getElementById('colGoalRemindmeDay').style.display = 'none'
                                    document.getElementById('colGoalTime').style.display = 'none'

                                    document.getElementById('formToAddOption').style.display = 'block'
                                    document.getElementById('buttonShowForm').style.display = 'none'
                                    document.getElementById('buttonHideForm').style.display = 'inline-block'
                                }

                            });

                            function showForm (id) {
        
                                if(id) {

                                    var personalGoalTemplates = <?php echo json_encode($personalGoalTemplates); ?>;
                                    var option = null
                                    
                                    personalGoalTemplates.forEach(element => {
                                        if(element.id == id){
                                            option = element
                                        }
                                    });

                                    document.getElementById("goalId").value = option.id
                                    document.getElementById("goalTemplate").value = option.goalTemplate
                                    document.getElementById("goalName").value = option.goalName
                                    document.getElementById("goalDescription").value = option.goalDescription
                                    document.getElementById(option.kindOfGoal).checked = true

                                    if(option.goalOften != "" && option.goalOften != null){
                                        document.getElementById(option.goalOften).checked = true
                                    }
                                    document.getElementById("goalDeadLine").value = option.goalDeadLine
                                    document.getElementById("goalRemindmeTime").value = option.goalRemindmeTime
                                    document.getElementById("goalRemindmeDay").value = option.goalRemindmeDay
                                    document.getElementById("goalTime").value = option.goalTime

                                    var radios = document.querySelectorAll('input[type=radio][name="kindOfGoal"]');
                                    radios.forEach(radio => {
                                        if (radio.value == 'onetime' && radio.checked) {
                                            document.getElementById('colGoalDeadLine').style.display = 'table-cell'
                                            document.getElementById('colGoalRemindmeTime').style.display = 'table-cell'
                                            document.getElementById('colGoalOften').style.display = 'none'
                                            document.getElementById('colGoalRemindmeDay').style.display = 'none'
                                            document.getElementById('colGoalTime').style.display = 'none'
                                        }
                                        else if (radio.value == 'ongoing' && radio.checked) {
                                            document.getElementById('colGoalOften').style.display = 'table-cell'
                                            document.getElementById('colGoalRemindmeDay').style.display = 'table-cell'
                                            document.getElementById('colGoalTime').style.display = 'table-cell'
                                            document.getElementById('colGoalDeadLine').style.display = 'none'
                                            document.getElementById('colGoalRemindmeTime').style.display = 'none'
                                        }
                                    });
                                    document.getElementById('formToAddOption').style.display = 'block'
                                    document.getElementById('buttonShowForm').style.display = 'none'
                                    document.getElementById('buttonHideForm').style.display = 'inline-block'
        
                                } else {
                                    
                                    var currentDate = new Date();
                                    var day = currentDate.getDay()
                                    var dayValue = ""


                                    switch (day) {
                                        case 1:
                                            dayValue = "monday"
                                        break;
                                        case 2:
                                            dayValue = "tuesday"
                                        break;
                                        case 3:
                                            dayValue = "wednesday"
                                        break;
                                        case 4:
                                            dayValue = "thursday"
                                        break;
                                        case 5:
                                            dayValue = "friday"
                                        break;
                                        case 6:
                                            dayValue = "saturday"
                                        break;
                                        case 7:
                                            dayValue = "sunday"
                                        break;
                                    }

                                    document.getElementById("goalId").value = ""
                                    Array.from( document.querySelectorAll('input[type=radio][name="kindOfGoal"]'), input => input.checked = false );
                                    Array.from( document.querySelectorAll('input[type=radio][name="goalOften"]'), input => input.checked = false );
                                    document.getElementById("goalTemplate").value = ""
                                    document.getElementById("goalName").value = ""
                                    document.getElementById("goalDescription").value = ""
                                    document.getElementById("goalDeadLine").value = new Date().toJSON().slice(0,10)
                                    document.getElementById("goalRemindmeTime").value = ""
                                    document.getElementById("goalRemindmeDay").value = dayValue
                                    document.getElementById("goalTime").value = ""

                                    document.getElementById('formToAddOption').style.display = 'block'
                                    document.getElementById('buttonShowForm').style.display = 'none'
                                    document.getElementById('buttonHideForm').style.display = 'inline-block'
                                }
                            }
        
                            function deleteGoalTemplate (data) {
        
                                var personalGoalTemplates = <?php echo json_encode($personalGoalTemplates); ?>;

                                personalGoalTemplates.forEach((element, index) => {
                                    if (element.id == data) {
                                        personalGoalTemplates.splice(index, 1);
                                    }
                                });
                                
                                console.log(personalGoalTemplates)

                                document.getElementById("updatedGoalTemplates").value = JSON.stringify(personalGoalTemplates)
                                document.getElementById('updateGoal').click();
        
                            }
        
                            function hideForm (){

                                document.getElementById("goalId").value = ""
                                Array.from( document.querySelectorAll('input[type=radio][name="kindOfGoal"]'), input => input.checked = false );
                                Array.from( document.querySelectorAll('input[type=radio][name="goalOften"]'), input => input.checked = false );
                                document.getElementById("goalTemplate").value = ""
                                document.getElementById("goalName").value = ""
                                document.getElementById("goalDescription").value = ""
                                document.getElementById("goalDeadLine").value = ""
                                document.getElementById("goalRemindmeTime").value = ""
                                document.getElementById("goalRemindmeDay").value = ""
                                document.getElementById("goalTime").value = ""

                                document.getElementById('formToAddOption').style.display = 'none'
                                document.getElementById('buttonShowForm').style.display = 'inline-block'
                                document.getElementById('buttonHideForm').style.display = 'none'
                                document.getElementById('colGoalDeadLine').style.display = 'none'
                                document.getElementById('colGoalRemindmeTime').style.display = 'none'
                                document.getElementById('colGoalOften').style.display = 'none'
                                document.getElementById('colGoalRemindmeDay').style.display = 'none'
                                document.getElementById('colGoalTime').style.display = 'none'
                            }
        
                        </script>
        
        
                    <?php 
                    break;
            }
            ?>

        </div><!-- End wrap -->

        <?php
    }
}
