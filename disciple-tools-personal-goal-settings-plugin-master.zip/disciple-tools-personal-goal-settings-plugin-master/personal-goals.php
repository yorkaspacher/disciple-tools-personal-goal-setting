<?php
    declare(strict_types=1);

    get_header();

    $post_settings = apply_filters( "dt_get_post_type_settings", [], $post_type );

    $field_options = $post_settings["fields"];

    $userPersonalGoals = get_user_meta(get_current_user_id(), 'vc_personal_goal', true ) ? json_decode(get_user_meta(get_current_user_id(), 'vc_personal_goal', true )) : [];

    ?>

    <div data-sticky-container class="hide-for-small-only" style="z-index: 9">
        <nav role="navigation"
             data-sticky data-options="marginTop:0;" style="width:100%" data-top-anchor="1"
             class="second-bar">
            <div class="container-width center"><!--  /* DESKTOP VIEW BUTTON AREA */ -->
                <a class="button dt-green" onclick="redirectToView()">
                    <img style="display: inline-block;" src="http://localhost/wordpress/wp-content/themes/disciple-tools-theme/dt-assets/images/add-group-white.svg"/>
                    <span>Create New Personal Goal</span>
                </a>
            </div>
        </nav>
    </div>


    <div id="content" class="archive-groups">

        <div id="inner-content" class="grid-x grid-margin-x">

            <main id="main" class="large-12 cell padding-bottom" role="main">

                <div class="bordered-box list-box">
                
                    <div class="section-header">
                        <span>
                            Personal Goal List
                        </span>
                    </div>

                    <table class="table-remove-top-border js-list stack striped">
                        <thead>
                            <tr class="sortable">
                                <th>Name</th>
                                <th>Kind Of Goal</th>
                                <th>Description</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($userPersonalGoals  as $option) : ?>
                            <tr>
                                <td>
                                <a onclick="showForm('<?php echo $option->id ?>')"><?php echo $option->goalName ?> <br/></a>
                                </td>
                                <td><?php echo $option->kindOfGoal ?></td>
                                <td><?php echo $option->goalDescription ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

            </main> <!-- end #main -->

        </div> <!-- end #inner-content -->

    </div> <!-- end #content -->

    <script type="application/javascript">

        
        function redirectToView(){

            console.log(window.location.href)
            window.location.href = window.location.href + '/new'
            // location.replace(window.location.href + '/new')
        }
        
        function showForm (id) {

                var personalGoalTemplates = <?php echo json_encode($userPersonalGoals); ?>;
                var option = null
                
                personalGoalTemplates.forEach(element => {
                    if(element.id == id){
                        option = element
                    }
                });

                localStorage.setItem('personalGoal', JSON.stringify(option));
                window.location.href = window.location.href + '/edit'

        }

    </script>
    
    <?php
    get_footer();
